# Capital Group discussion — synthetic agentic onboarding demo

Start with Agentic_Demo_Walkthrough.md for the 20-minute presenter script.

This package demonstrates the call's context-aware historical-case and tailored-playbook use case. It contains 54 synthetic documents, 157 passage IDs, 12 historical cases, current operating constraints, later client evidence, six prepared agent handoffs, three proposed workflow revisions, retrieval examples and evaluation checks.

The hosted page replays prepared AI-authored analysis. Local source search, filtering, calculations, illustrative rule tests, plan state and human-review controls execute in the page. There is no live model endpoint and no production-system connection. No actual Capital Group client, policy, operating capability or forecast is represented.

Files:
- corpus/: 54 individual Markdown/email source documents.
- Corpus_Manifest.json: metadata, passage text, case records and file hashes.
- Corpus_Initial_Snapshot.md: 52 initial-date sources, including clearly superseded O02; excludes later N07/N08. Use for live model reasoning.
- Corpus_All_Documents.md: all 54 sources for presenter preparation.
- Agentic_Demo_Walkthrough.md: exact talk track, source examples, questions and expected changes.
- Agent_Prompts_and_Handoffs.md: role prompts and human review checkpoints for a fresh live analysis in an AI workspace.
- Prepared_Trace_initial.json, Prepared_Trace_clarified.json, Prepared_Trace_cash.json: inspectable prepared outputs with local retrieval results; not live model logs.
- Retrieval_Examples.json: local lexical candidates and separately identified prepared semantic selections.
- Evaluation_Checklist.json: 12 substantive acceptance checks for fresh model output; not a production benchmark.
- Validation_Summary.json: actual local verification and its limits.

Sources are entirely synthetic. Later scenario dates are deliberate fictional snapshots. The workflow ends in human-reviewed planning; it does not open an account, execute an agreement, approve investment intent or instruct funding/trades.

Observed reporting rework in five selected synthetic initial requests is 4/5; affected median is 10 business days. These are descriptive historical examples, not a calibrated 80% risk or a launch-delay forecast. Coal >=10% and data age >30 days are illustrative assumptions requiring new-client review.
