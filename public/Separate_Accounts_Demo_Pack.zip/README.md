# Separate Account Navigator - demonstration pack

Start with Presenter_Guide.pdf. Source_Pack.pdf combines D01-D13; documents/ contains individual PDFs. Scenario_Data.json contains source text, the canonical fictional client, twelve holdings, four initial risks and seven workstreams. Implementation_Blueprint.pdf describes a four-week live-AI pilot.

This is a synthetic demonstration prepared for discussion with Capital Group. It is not a real account, legal agreement, approval or system capability statement. The interactive site uses deterministic scenario logic, local browser state and simulated reviewers/integrations. No email, financial transaction or production change is performed.

Guided sequence: load D10 and initiate as GCS Operations; load D09, run the screen, approve Legal then FI PC; load D11, approve Reporting and Transition; inject D12, explore staged launch, reapprove Legal/FI PC/Transition; load D13, approve staged scope as GCS Operations; release as Operations Checker; simulate receipt.

Amount checks: 200m initial in-kind + 50m cash = 250m. Two exclusions and one unknown are 30m total. Nine accepted positions = 170m; cash becomes 80m. Corporate concentration denominator is the full 250m mandate.

Date checks: original 23 Nov 2026; proposed 9 Nov; derivatives estimate 16 Nov. Staged launch disables derivatives until separately approved.

All names and identifiers are synthetic. Documents use example.com addresses. No real bank details or signatures are included. The only client-specific process evidence is the supplied meeting-summary/process images; no full verbatim transcript was available.
